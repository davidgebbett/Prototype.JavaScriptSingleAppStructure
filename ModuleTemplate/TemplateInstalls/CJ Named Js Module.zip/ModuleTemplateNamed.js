﻿(function () {
    var $itemname$ = {
        init: function () {
            $itemname$.start();
        },
        start: function () {
        },
        api: {
        }
    };
    $itemname$.init();
    module.exports = $itemname$.api;
}());