﻿(function () {
    var mod = {
        init: function () {
            mod.start();
        },
        start: function () {
        },
        api: {
        }
    };
    mod.init();
    mod.exports = mod.api;
}());